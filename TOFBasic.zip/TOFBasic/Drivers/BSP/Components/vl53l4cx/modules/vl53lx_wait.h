/**
 ******************************************************************************
 * Copyright (c) 2020, STMicroelectronics - All Rights Reserved
 *
 * This software is licensed under terms that can be found in the LICENSE file
 * in the root directory of this software component.
 * If no LICENSE file comes with this software, it is provided AS-IS.
 *
 ******************************************************************************
 */




#ifndef _VL53LX_WAIT_H_
#define _VL53LX_WAIT_H_

#include "vl53lx_platform.h"

#ifdef __cplusplus
extern "C" {
#endif




VL53LX_Error VL53LX_wait_for_boot_completion(
	VL53LX_DEV      Dev);




VL53LX_Error VL53LX_wait_for_range_completion(
	VL53LX_DEV   Dev);




VL53LX_Error VL53LX_wait_for_test_completion(
	VL53LX_DEV   Dev);






VL53LX_Error VL53LX_is_boot_complete(
	VL53LX_DEV      Dev,
	uint8_t        *pready);



VL53LX_Error VL53LX_is_firmware_ready(
	VL53LX_DEV      Dev,
	uint8_t        *pready);




VL53LX_Error VL53LX_is_new_data_ready(
	VL53LX_DEV      Dev,
	uint8_t        *pready);






VL53LX_Error VL53LX_poll_for_boot_completion(
	VL53LX_DEV      Dev,
	uint32_t        timeout_ms);




VL53LX_Error VL53LX_poll_for_firmware_ready(
	VL53LX_DEV      Dev,
	uint32_t        timeout_ms);




VL53LX_Error VL53LX_poll_for_range_completion(
	VL53LX_DEV   Dev,
	uint32_t     timeout_ms);



#ifdef __cplusplus
}
#endif

#endif

